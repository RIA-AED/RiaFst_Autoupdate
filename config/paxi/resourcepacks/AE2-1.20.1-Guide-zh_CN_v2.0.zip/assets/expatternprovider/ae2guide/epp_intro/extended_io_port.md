---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME扩展IO端口
    icon: expatternprovider:ex_io_port
categories:
- extended devices
item_ids:
- expatternprovider:ex_io_port
---

# ME扩展IO端口

<Row gap="20">
<BlockImage id="expatternprovider:ex_io_port" p:powered="true" scale="8"></BlockImage>
</Row>

ME扩展IO端口的工作速度是标准版<ItemLink id="ae2:io_port" />的8倍，并具备以下强化特性：
- 传输效率提升至8倍速（可配置调整）
- 扩展升级插槽数量