---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME原料缓存器
    icon: expatternprovider:ingredient_buffer
categories:
- extended devices
item_ids:
- expatternprovider:ingredient_buffer
---

# ME原料缓存器

<BlockImage id="expatternprovider:ingredient_buffer" scale="8"></BlockImage>

一种多功能存储装置，可同时缓存36种不同类型的物质，涵盖从基础物品到流体的多样化存储需求。