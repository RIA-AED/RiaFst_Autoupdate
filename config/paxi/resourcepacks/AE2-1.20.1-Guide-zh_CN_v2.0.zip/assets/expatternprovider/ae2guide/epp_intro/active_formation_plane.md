---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME主动成型面板
    icon: expatternprovider:active_formation_plane
categories:
- extended devices
item_ids:
- expatternprovider:active_formation_plane
---

# ME主动成型面板

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

ME主动成型面板是一种能主动放置方块或掉落物品的<ItemLink id="ae2:formation_plane" />变体。

您无需为其设置子网络。其工作方式类似于<ItemLink id="ae2:export_bus" />，但会直接放置方块而非输出到容器中。