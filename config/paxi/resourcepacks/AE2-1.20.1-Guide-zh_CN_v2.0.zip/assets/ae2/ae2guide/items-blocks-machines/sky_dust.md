---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 陨石粉
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# 陨石粉

<ItemImage id="sky_dust" scale="4" />

被<ItemLink id="inscriber" />（压印器）粉碎的<ItemLink id="sky_stone_block" />（陨石）。用于制作<ItemLink id="cell_component_256k" />（256k ME存储组件）和陨石块。

也可通过将<ItemLink id="annihilation_plane" />（ME破坏面板）朝上放置在世界高度上限处获得。

## 合成配方

<RecipeFor id="sky_dust" />