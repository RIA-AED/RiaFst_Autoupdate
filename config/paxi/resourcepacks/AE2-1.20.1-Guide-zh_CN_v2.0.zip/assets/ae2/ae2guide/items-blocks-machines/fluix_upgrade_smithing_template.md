---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯升级锻造模板
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# 福鲁伊克斯升级锻造模板

与[原版锻造模板](https://zh.minecraft.wiki/w/%E9%94%BB%E9%80%A0%E6%A8%A1%E6%9D%BF)不同，你可以从头制作这种模板。

这是制作[福鲁伊克斯工具](fluix_tools.md)的必需物品。

## 合成配方

<RecipeFor id="fluix_upgrade_smithing_template" />