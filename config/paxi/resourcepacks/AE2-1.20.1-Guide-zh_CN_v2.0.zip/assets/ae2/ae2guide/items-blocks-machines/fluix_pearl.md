---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯珍珠
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# 福鲁伊克斯珍珠

<ItemImage id="fluix_pearl" scale="4" />

包裹着<ItemLink id="fluix_crystal" />的末影珍珠，用于制造多种AE2组件。

## 合成配方

<RecipeFor id="fluix_pearl" />