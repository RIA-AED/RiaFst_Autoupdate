---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 石英玻璃
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# 石英玻璃

<BlockImage id="quartz_glass" scale="8" />

主要由<ItemLink id="certus_quartz_dust" />（赛特斯石英粉）制成的透明玻璃，用于制作多种AE2机器和物品。

还有一种变种——聚能石英玻璃，能够发出光亮。

## 合成配方

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />