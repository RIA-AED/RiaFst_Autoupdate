---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 末影粉
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# 末影粉

<ItemImage id="ender_dust" scale="4" />

经<ItemLink id="inscriber" />压印器粉碎的末影珍珠。用于制造<ItemLink id="wireless_booster" />无线增强器
和成对<ItemLink id="quantum_entangled_singularity" />量子纠缠奇点。

## 配方

<RecipeFor id="ender_dust" />